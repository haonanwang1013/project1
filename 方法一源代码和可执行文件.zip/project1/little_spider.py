import requests as re
session = re.session()

headers = {
    "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36",
    
}

userInfor = {
    "username": "15279706155",
    "password" : "project1",
    "checkhash" :""
}

respon1 = session.post("http://www.pigai.org/index.php?a=login", data = userInfor, headers = headers)


check = session.get("http://www.pigai.org/index.php?c=write&f2=login", headers = headers)

respon2 = session.get("http://www.pigai.org/?c=v2&a=write&rid=10", headers = headers)

relace_dict = {
    "," : "%2C",
    
}

articles = input("Please input your article here\nWarning: If there are multiple paragraphs in your essay, please input '%0A' instead of Pressing enter simply\nBecause enter is the end of your input\n")


articles = articles.replace("\n", "%0A")
article_form = {
    "utContent" : articles,
    "utTitle":"%E8%87%AA%E6%B5%8B%E7%BB%83%E4%B9%A0",
    "bzold" : '',
    'bz':'',
    'fileName': '',
    'filePath':'' ,
    'rid': '10',
    'eid': '',
    'type': '0',
    'utype': '',
    'gao': '1',
    'uncheck': '',
    'tiku_id': '0',
    'engine': '',
    'fromCode': ''
    
}

post_article = session.post("http://www.pigai.org/index.php?c=ajax&a=postSave", headers = headers, data = article_form)

print(post_article.text)
eid = post_article.text.split("=")[1]

try_data = {
    "eid" : eid,
    "icomet":""
}

post_another = session.post("https://www.pigai.org/index.php?c=ajax&a=processStartIcomet", data = try_data, headers = headers)

after_post1 = session.get("http://www.pigai.org/icomet/sign?cb=icomet_cb_0&cname="+"pg_" + eid + "_"+"&_=&callback=cb", headers = headers)
print(after_post1.text)


after_post2 = session.get("http://www.pigai.org/icomet/sub?cb=icomet_cb_0&cname="+"pg_" + eid + "_"+"&seq=0&noop=0&token=&_=&callback=cb&_=", headers = headers)
print(after_post2.text)

#after_post3 = session.get("http://www.pigai.org/icomet/sub?cb=icomet_cb_0&cname="+"pg_" + eid + "_"+"&seq=5&noop=0&token=&_=&callback=cb&_=", headers = headers)
# print(after_post3.text)



grade_data = {
    "cb":"icomet_cb_0",
    "cname":"",
    "seq":"3",
    "noop": "0",
    "token":"",
    "_":"",
    "callback":"cb"
}
grade_get = session.get("http://www.pigai.org/icomet/sub?callback=cb&cb=icomet_cb_0&token=&_=&seq=3&cname=&noop=0",headers = headers)
# print(grade_get.text)

new_headers = {
    "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.131 Safari/537.36",
    "Referer" : "http://www.pigai.org/index.php?c=v2&a=write&eid=" + eid + "&rid=10",
    "Host" : "www.pigai.org",
    "Origin": "https://www.pigai.org",
    "Connection":"keep-alive",
    "X-Requested-With":"XMLHttpRequest",
    }


comments = session.get("http://www.pigai.org/?c=v2&a=view&eid=" + eid, headers = new_headers)

#the code below targeted at processing the soup
from bs4 import BeautifulSoup

soup = BeautifulSoup(comments.text)

soup.title.string = "Hello world"
print(soup.title.string)

for a in soup.find_all("script"):
    a.decompose()
for b in soup.find_all("link"):
    b.decompose()

for c in soup.find_all("div", id = "pigai_yaoqiu"):
    c.decompose()

for d in soup.find_all("div", id = "lg_footer"):
    d.decompose()
for e in soup.find_all("div", class_ = "ttabw"):
    e.decompose()
    
for e in soup.find_all("div", class_ = "stips_fb"):
    e.decompose()
for f in soup.find_all("div", id = "infotipW"):
    f.decompose()

for g in soup.find_all("div", id = "pigai_tuijian"):
    g.decompose()

for g in soup.find_all("div", id = "topLink"):
    g.decompose()
for g in soup.find_all("div", id = "tipsContext"):
    g.decompose()
for g in soup.find_all("div", id = "pigai_zhou"):
    g.decompose()
for g in soup.find_all("div", id = "i_fanwen"):
    g.decompose()
for g in soup.find_all("div", id = "yaoqiu"):
    g.decompose()
for h in soup.find_all("div", class_ = "view3Item view3duan"):
    h.decompose()
for i in soup.find_all("img"):
    i.decompose()
for j in soup.find_all("ul", id = "header_navi"):
    j.decompose()

with open("d.html", 'w', encoding="utf-8") as f:
    f.write(soup.prettify())

heheda = input("Please check the output file 'd.html' in the same folder")
